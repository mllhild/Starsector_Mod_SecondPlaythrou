package mllhild.spm.campaign.skills;


import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.characters.DescriptionSkillEffect;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.Iterator;

public class spm_Row1Skils {
    public spm_Row1Skils(){}

    public static Boolean hasSkill(String skillID) {
        Iterator i$ = Global.getSector().getPlayerStats().getSkillsCopy().iterator();

        MutableCharacterStatsAPI.SkillLevelAPI skill;
        do {
            if (!i$.hasNext()) {
                return false;
            }

            skill = (MutableCharacterStatsAPI.SkillLevelAPI)i$.next();
        } while(skill.getSkill().getId() != skillID || !(skill.getLevel() > 0.0F));

        return true;
    }

    public static class Level0 implements DescriptionSkillEffect {
        public Level0() {
        }

        public String getString() {
            return "    - These skills are automatically granted after certain events.\n    - \nDue to vanilla limitations, active milestones may make it impossible to reassign skills normally.To fix this: toggle milestones off, wait until they disappear, reassign, and toggle milestones back on.";
        }

        public Color[] getHighlightColors() {
            Color h = Misc.getHighlightColor();
            Color s = Misc.getStoryOptionColor();
            return new Color[]{h, h, h, s};
        }

        public String[] getHighlights() {
            return new String[]{""};
        }

        public Color getTextColor() {
            return Misc.getTextColor();
        }
    }
}
