package mllhild.spm.ids;

public class spm_ids {
    public static final String SECTOR_ACCESS_BASE = "spm_access_base";
    public static final String SECTOR_ACCESS_10 = "spm_access_10";
    public static final String SECTOR_ACCESS_20 = "spm_access_20";
    public static final String SECTOR_ACCESS_30 = "spm_access_30";
    public static final String SECTOR_ACCESS_40 = "spm_access_40";
    public static final String SECTOR_ACCESS_50 = "spm_access_50";
    public static final String SECTOR_ACCESS_60 = "spm_access_60";
    public static final String SECTOR_ACCESS_70 = "spm_access_70";
    public static final String SECTOR_DECAY_LV1 = "spm_decay_lv1";
    public static final String SECTOR_DECAY_LV2 = "spm_decay_lv2";
    public static final String SECTOR_DECAY_LV3 = "spm_decay_lv3";
}
