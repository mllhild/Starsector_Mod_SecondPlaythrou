package mllhild.spm;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import lunalib.lunaSettings.LunaSettings;
import com.fs.starfarer.api.campaign.listeners.FleetEventListener;
import mllhild.spm.util.CustomExplorationStart.spm_CustomExplorationStart;
import mllhild.spm.util.CustomExplorationStart.spm_intelEntity;
import mllhild.spm.util.FreeStorageRevamp.*;
import mllhild.spm.util.Misc.spm_playerRenown;
import mllhild.spm.util.PermanentWar.spm_warmode;
import mllhild.spm.util.RandomSector.spm_accessbonus;
import mllhild.spm.util.RandomSector.sqm_RandomSector_Main;
import mllhild.spm.util.UAF.deephyper.spm_uaf_generatePseudoTerrain;
import mllhild.spm.util.UAF.deephyper.spm_uaf_AbyssTravelEveryFrameScript;
//import mllhild.spm.util.UAF.old.spm_uaf_abyssUafSensor;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.List;


public class SecondPlaythrouModPlugin extends BaseModPlugin {
    private static final Logger log = Logger.getLogger(SecondPlaythrouModPlugin.class);

    public SecondPlaythrouModPlugin() {
    }

    @Override
    public void onApplicationLoad() throws Exception {
        super.onApplicationLoad();
    }

    @Override
    public void onNewGame() {
        super.onNewGame();
    }

    @Override
    public void onGameLoad(boolean newGame) {
        log.info("SPM onGameLoad Start");
        if(!newGame){
            Global.getSector().addTransientScript(new spm_warmode());
            if(LunaSettings.getBoolean("SecondPlaythrou", "freeStorageLocations"))
                {new spm_abandonedStationSettings().RemoveMarket();}
            if(LunaSettings.getBoolean("SecondPlaythrou", "player_renown"))
                if(!Global.getSector().getListenerManager().getListeners(spm_playerRenown.class).isEmpty()){
                    log.info("Did not find existing spm_playerRenown");
                    Global.getSector().getListenerManager().addListener(new spm_playerRenown());
                }else {log.info("Did find existing spm_playerRenown");}
        }
        log.info("SPM onGameLoad End");
    }

    @Override
    public void onNewGameAfterProcGen() {
        log.info("SPM onNewGameAfterProcGen Start");
        if(LunaSettings.getBoolean("SecondPlaythrou", "freeStorageLocations"))
            {new spm_abandonedStationSettings().RemoveMarket();}
        log.info("SPM onNewGameAfterProcGen End");
    }

    @Override
    public void onNewGameAfterTimePass() {
        log.info("SPM onNewGameAfterTimePass Start");
        new spm_CustomExplorationStart().LunaStart();
        if(LunaSettings.getBoolean("SecondPlaythrou", "player_renown"))
            Global.getSector().getListenerManager().addListener(new spm_playerRenown());
        log.info("SPM onNewGameAfterTimePass End");
    }

    @Override
    public void onNewGameAfterEconomyLoad() {
        log.info("SPM onNewGameAfterEconomyLoad Start");
        new sqm_RandomSector_Main().LunaStart();
        if(LunaSettings.getBoolean("SecondPlaythrou", "randomCore_accessBonus"))
            new spm_accessbonus().GiveAccessBonus();
        Global.getSector().addTransientScript(new spm_warmode());
        log.info("SPM onNewGameAfterEconomyLoad End");
    }
}
