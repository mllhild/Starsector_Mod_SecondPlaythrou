package mllhild.spm.util.ColonyCrises;



import java.awt.Color;
import java.util.List;

import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.Strings;
import com.fs.starfarer.api.impl.campaign.intel.events.BaseEventFactor;
import com.fs.starfarer.api.impl.campaign.intel.events.BaseEventIntel;
import com.fs.starfarer.api.impl.campaign.intel.events.HAColonyDefensesFactor;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI.TooltipCreator;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.impl.campaign.intel.*;
import lunalib.lunaSettings.LunaSettings;

public class spm_colonyCrisisSpeed extends HAColonyDefensesFactor {

    public static float PATROL_HQ_MULT = 0.9f;
    public static float MILITARY_BASE_MULT = 0.7f;
    public static float HIGH_COMMAND_MULT = 0.5f;

    @Override
    public float getAllProgressMult(BaseEventIntel intel) {
        HAColonyDefensesFactor.HAColonyDefenseData data = getDefenseData(intel);
        double d = LunaSettings.getDouble("SecondPlaythrou", "colony_crisis_speedFactor");
        return data.mult * (float)d;
    }

    @Override
    public HAColonyDefenseData getDefenseData(BaseEventIntel intel) {
        HAColonyDefenseData best = new HAColonyDefenseData();

        List<MarketAPI> markets = Misc.getPlayerMarkets(false);
        for (MarketAPI market : markets) {
            float mult = 1f;
            Industry industry = null;
            if (market.hasFunctionalIndustry(Industries.PATROLHQ)) {
                mult = PATROL_HQ_MULT;
                industry = market.getIndustry(Industries.PATROLHQ);
            }
            if (Misc.isMilitary(market)) {
                if (market.hasFunctionalIndustry(Industries.HIGHCOMMAND)) {
                    mult = HIGH_COMMAND_MULT;
                    industry = market.getIndustry(Industries.HIGHCOMMAND);
                } else {
                    mult = MILITARY_BASE_MULT;
                    industry = market.getIndustry(Industries.MILITARYBASE);
                }
            }

            if (industry != null && mult < best.mult) {
                best.market = market;
                best.industry = industry;
                best.mult = mult;
            }
        }

        double d = LunaSettings.getDouble("SecondPlaythrou", "colony_crisis_speedFactor");
        best.mult = best.mult * (float)d;
        return best ;
    }
}
