package mllhild.spm.util.SectorDecay;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import java.util.Iterator;

import mllhild.spm.SecondPlaythrouModPlugin;
import org.apache.log4j.Logger;

public class spm_SectorDecay {
    private static final Logger log = Logger.getLogger(SecondPlaythrouModPlugin.class);
    boolean sectorWillDecay = false;
    int sectorDecaySpeed = 50;
    int sectorLastDecayDate = 500;
    float lv1timer = 1.0F;
    float lv2timer = 2.0F;
    float lv3timer = 3.0F;

    public spm_SectorDecay() {
    }

    public void AddLevelOfDecayToAllMarkets() {
        log.info("AddLevelOfDecayToAllMarkets Start");
        this.CheckDecayTimer();
        Iterator i1 = Global.getSector().getStarSystems().iterator();

        while(i1.hasNext()) {
            StarSystemAPI system = (StarSystemAPI)i1.next();
            Iterator i2 = system.getPlanets().iterator();

            while(i2.hasNext()) {
                PlanetAPI planet = (PlanetAPI)i2.next();
                MarketAPI market = planet.getMarket();
                if (market != null) {
                    market.addCondition("xcw_sector_decay_lv1");
                    market.removeCondition("xcw_sector_decay_lv1");
                    market.addCondition("xcw_sector_decay_lv2");
                    market.removeCondition("xcw_sector_decay_lv2");
                    market.addCondition("xcw_sector_decay_lv3");
                }
            }
        }

        log.info("AddLevelOfDecayToAllMarkets End");
    }

    public void CheckDecayTimer() {
        log.info("CheckDecayTimer Start");
        int day = Global.getSector().getClock().getDay();
        log.info("Day: " + day);
        log.info("CheckDecayTimer End");
    }
}