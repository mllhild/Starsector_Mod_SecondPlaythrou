package mllhild.spm.util.FreeStorageRevamp;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.AbilityPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.submarkets.StoragePlugin;
import mllhild.spm.SecondPlaythrouModPlugin;
import org.apache.log4j.Logger;

import java.util.Map;

public class spm_abandonedStationSettings {
    private static final Logger log = Logger.getLogger(SecondPlaythrouModPlugin.class);
    public void RemoveMarket(){
        log.info("------------- Remove Abandoned Station Submarket Start -------------");
        for(SectorEntityToken entityToken : Global.getSector().getEntitiesWithTag("station")){

            log.info("  System: " + entityToken.getStarSystem().getName() + "  Name: " + entityToken.getName() + "  ID: " + entityToken.getId());
            String tags = "";
            for(String tag : entityToken.getTags()) {tags = tags + tag + ", ";}
            log.info("      tags: " + tags);
            MarketAPI stationMarket = entityToken.getMarket();
            if(stationMarket != null){
                if(stationMarket.hasCondition(Conditions.ABANDONED_STATION)){
                    entityToken.setMarket(null);
                    entityToken.setCustomDescriptionId("descriptionTextAbandonedStationNoMarket");

                }
            }
        }
        log.info("------------- Remove Abandoned Station Submarket End -------------");
    }

    public void AddBlackMarket(){
        log.info("------------- Change Abandoned Station Market Start -------------");
        for(SectorEntityToken entityToken : Global.getSector().getEntitiesWithTag("station")){

            log.info("  System: " + entityToken.getStarSystem().getName() + "  Name: " + entityToken.getName() + "  ID: " + entityToken.getId());
            String tags = "";
            for(String tag : entityToken.getTags()) {tags = tags + tag + ", ";}
            log.info("      tags: " + tags);
            MarketAPI stationMarket = entityToken.getMarket();
            if(stationMarket != null){
                if(stationMarket.hasCondition(Conditions.ABANDONED_STATION)){
                    stationMarket.addSubmarket(Submarkets.SUBMARKET_BLACK);
                    stationMarket.removeSubmarket(Submarkets.SUBMARKET_STORAGE);
                    entityToken.setCustomDescriptionId("descriptionTextAbandonedStationBlackMarket");
                }
            }
        }
        log.info("------------- Change Abandoned Station Market End -------------");
    }
}
