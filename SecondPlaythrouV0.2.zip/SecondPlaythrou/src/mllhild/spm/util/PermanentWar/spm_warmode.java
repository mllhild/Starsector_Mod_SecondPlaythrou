package mllhild.spm.util.PermanentWar;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import mllhild.spm.SecondPlaythrouModPlugin;
import org.apache.log4j.Logger;
import lunalib.lunaSettings.LunaSettings;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;


import java.util.Arrays;
import java.util.List;

public class spm_warmode implements EveryFrameScript{
    public spm_warmode(){
        log.info("SPM Warmode --- Start");

        this.warmode = LunaSettings.getString("SecondPlaythrou", "warmode");
        log.info("Warmode: " + this.warmode);

        if(warmode.trim().equalsIgnoreCase("Two sided War")){
            log.info("is Two Sided War ---> split strings");
            twoSidedWar = true;
            String settingValueAxis = LunaSettings.getString("SecondPlaythrou", "groupAxis");
            if (settingValueAxis != null) {
                this.groupAxis = settingValueAxis.trim().split("\\s*,\\s*"); // Trims spaces around commas
            } else {
                this.groupAxis = new String[0]; // Handle null case gracefully
            }
            String settingValueAllies = LunaSettings.getString("SecondPlaythrou", "groupAllies");
            if (settingValueAllies != null) {
                this.groupAllies = settingValueAllies.trim().split("\\s*,\\s*"); // Trims spaces around commas
            } else {
                this.groupAllies = new String[0]; // Handle null case gracefully
            }
        }

        if(warmode.trim().equalsIgnoreCase("All Mod factions hate you"))
            allModFactionsHateYou = true;
        if(warmode.trim().equalsIgnoreCase("All Vanilla factions hate you"))
            allVanillaFactionsHateYou = true;
        if(warmode.trim().equalsIgnoreCase("All factions hate you"))
            allFactionsHateYou = true;
        if(warmode.trim().equalsIgnoreCase("Total War"))
            totalWar = true;
        if(warmode.trim().equalsIgnoreCase("Third AI War"))
            thirdAIWar = true;
        if(warmode.trim().equalsIgnoreCase("normal"))
            normalWar = true;



        String settingValuePlayerEnemies = LunaSettings.getString("SecondPlaythrou", "hatePlayer");

        if (settingValuePlayerEnemies != null) {
            log.info("Getting list of factions who hate the player");
            this.hatePlayer = settingValuePlayerEnemies.trim().split("\\s*,\\s*"); // Trims spaces around commas
        } else {
            this.hatePlayer = new String[0]; // Handle null case gracefully
        }


        warexchastion = LunaSettings.getBoolean("SecondPlaythrou", "warexchastion");

        hatedBy_pirates = LunaSettings.getBoolean("SecondPlaythrou", "hatedBy_pirates");
        hatedBy_perseanLeague = LunaSettings.getBoolean("SecondPlaythrou", "hatedBy_perseanLeague");
        hatedBy_hegemony = LunaSettings.getBoolean("SecondPlaythrou", "hatedBy_hegemony");
        hatedBy_ludicPath = LunaSettings.getBoolean("SecondPlaythrou", "hatedBy_ludicPath");
        hatedBy_ludicChurch = LunaSettings.getBoolean("SecondPlaythrou", "hatedBy_ludicChurch");
        hatedBy_tritachyon = LunaSettings.getBoolean("SecondPlaythrou", "hatedBy_tritachyon");
        hatedBy_remnants = LunaSettings.getBoolean("SecondPlaythrou", "hatedBy_remnants");
        hatedBy_indipendant = LunaSettings.getBoolean("SecondPlaythrou", "hatedBy_indipendant");
        hatedBy_syndrianDiktat = LunaSettings.getBoolean("SecondPlaythrou", "hatedBy_syndrianDiktat");

        log.info("SPM Warmode --- End");
    };

    String warmode = "normal";
    String[] groupAxis = null;
    String[] groupAllies = null;
    String[] hatePlayer = null;
    Boolean warexchastion = true;

    Boolean hatedBy_pirates = false;
    Boolean hatedBy_perseanLeague = false;
    Boolean hatedBy_hegemony = false;
    Boolean hatedBy_ludicPath = false;
    Boolean hatedBy_ludicChurch = false;
    Boolean hatedBy_tritachyon = false;
    Boolean hatedBy_remnants = false;
    Boolean hatedBy_indipendant = false;
    Boolean hatedBy_syndrianDiktat = false;

    Boolean allVanillaFactionsHateYou = false;
    Boolean allModFactionsHateYou = false;
    Boolean allFactionsHateYou = false;
    Boolean totalWar = false;
    Boolean thirdAIWar = false;
    Boolean normalWar = true;
    Boolean twoSidedWar = false;


    private static final Logger log = Logger.getLogger(SecondPlaythrouModPlugin.class);

    public IntervalUtil fireInterval = new IntervalUtil(6000f, 1200f);




    @Override
    public boolean isDone() {return false;}

    @Override
    public boolean runWhilePaused() {return false;}

    @Override
    public void advance(float amount) {

        fireInterval.advance(1f);
        if (fireInterval.intervalElapsed()){
            warmodeRun();
        }
    }


    public void warmodeRun(){
        log.info(warmode);
        FactionAPI playerFaction = Global.getSector().getPlayerFaction();
        if(warexchastion){
            // check nexerelin warexchaustion
        }
        if(normalWar){

        }

        if(hatedBy_pirates){playerFaction.setRelationship("pirates",-90f); }
        if(hatedBy_perseanLeague){playerFaction.setRelationship("persean",-90f); }
        if(hatedBy_hegemony){playerFaction.setRelationship("hegemony",-90f); }
        if(hatedBy_ludicPath){playerFaction.setRelationship("luddic_path",-90f); }
        if(hatedBy_ludicChurch){
            playerFaction.setRelationship("knights_of_ludd",-90f);
            playerFaction.setRelationship("luddic_church",-90f);
        }
        if(hatedBy_tritachyon){playerFaction.setRelationship("tritachyon",-90f); }
        if(hatedBy_remnants){playerFaction.setRelationship("remnant",-90f); }
        if(hatedBy_indipendant){
            playerFaction.setRelationship("independent",-90f);
            playerFaction.setRelationship("mercenary",-90f);
            playerFaction.setRelationship("scavengers",-90f);
        }
        if(hatedBy_syndrianDiktat){
            playerFaction.setRelationship("sindrian_diktat",-90f);
            playerFaction.setRelationship("lions_guard",-90f);
        }


        if(allFactionsHateYou){
            for(FactionAPI faction : Global.getSector().getAllFactions()){
                if(!faction.getId().equalsIgnoreCase(playerFaction.getId()) && !faction.getId().equalsIgnoreCase("neutral")){
                    playerFaction.setRelationship(faction.getId(),-90);
                }
            }
        }

        if(allVanillaFactionsHateYou){ AllVanillaFactionsHateYou(playerFaction); }
        if(allModFactionsHateYou){ AllModFactionsHateYou(playerFaction); }

        if(hatePlayer.length > 0){
            for(String factionID : hatePlayer){
                FactionAPI faction = Global.getSector().getFaction(factionID);
                if(faction != null)
                    playerFaction.setRelationship(faction.getId(),-90);
            }
        }

        if(totalWar){
            for(FactionAPI faction1 : Global.getSector().getAllFactions())
                for(FactionAPI faction2 : Global.getSector().getAllFactions())
                    if(!faction1.getId().equals(faction2.getId()))
                        faction1.setRelationship(faction2.getId(), -90);
        }

        if(thirdAIWar){
            Global.getSector().getFaction("hegemony").setRelationship("knights_of_ludd",100f);
            Global.getSector().getFaction("hegemony").setRelationship("luddic_church",100f);
            Global.getSector().getFaction("hegemony").setRelationship("sindrian_diktat",100f);

            Global.getSector().getFaction("tritachyon").setRelationship("persean",100f);
            Global.getSector().getFaction("tritachyon").setRelationship("remnant",100f);
            Global.getSector().getFaction("remnant").setRelationship("persean",100f);

            Global.getSector().getFaction("tritachyon").setRelationship("luddic_church",-100f);
            Global.getSector().getFaction("tritachyon").setRelationship("hegemony",100f);
            Global.getSector().getFaction("tritachyon").setRelationship("luddic_path",100f);
            Global.getSector().getFaction("tritachyon").setRelationship("sindrian_diktat",100f);
            Global.getSector().getFaction("persean").setRelationship("luddic_church",-100f);
            Global.getSector().getFaction("persean").setRelationship("hegemony",100f);
            Global.getSector().getFaction("persean").setRelationship("luddic_path",100f);
            Global.getSector().getFaction("persean").setRelationship("sindrian_diktat",100f);
        }

        if(twoSidedWar){
            log.info("spm_warmode twoSidedWar --- Start");
            for(String faction1 : groupAxis){
                FactionAPI f1 = Global.getSector().getFaction(faction1);
                for(String faction2 : groupAxis){
                    f1.setRelationship(faction2,-90);
                    log.info(faction1 + " hates " + faction2);
                }
            }
            log.info("spm_warmode twoSidedWar --- End");
        }
    }


    public void AllVanillaFactionsHateYou(FactionAPI playerFaction){
        log.info("spm_warmode AllVanillaFactionsHateYou --- Start");
        playerFaction.setRelationship("pirates",-90f);
        playerFaction.setRelationship("persean",-90f);
        playerFaction.setRelationship("hegemony",-90f);
        playerFaction.setRelationship("luddic_path",-90f);
        playerFaction.setRelationship("knights_of_ludd",-90f);
        playerFaction.setRelationship("luddic_church",-90f);
        playerFaction.setRelationship("independent",-90f);
        playerFaction.setRelationship("mercenary",-90f);
        playerFaction.setRelationship("scavengers",-90f);
        playerFaction.setRelationship("sindrian_diktat",-90f);
        playerFaction.setRelationship("lions_guard",-90f);
        log.info("spm_warmode AllVanillaFactionsHateYou --- End");
    }

    public void AllModFactionsHateYou(FactionAPI playerFaction){
        log.info("spm_warmode AllModFactionsHateYou --- Start");
        String[] vanillaFactions = {
                "pirates",
                "persean",
                "hegemony",
                "luddic_path",
                "knights_of_ludd",
                "luddic_church",
                "tritachyon",
                "remnant",
                "independent",
                "mercenary",
                "scavengers",
                "sindrian_diktat",
                "lions_guard",
                "neutral",
                "omega",
                "poor",
                "derelict",
                "sleeper"};
        for(FactionAPI faction : Global.getSector().getAllFactions()) {
            //log.info(faction.getId());
            if (!faction.getId().equalsIgnoreCase(playerFaction.getId())) {
                if (!Arrays.asList(vanillaFactions).contains(faction.getId())) {
                    playerFaction.setRelationship(faction.getId(), -90);
                    //log.info(faction.getId() + " will always hate you." );
                }
                else{
                    //log.info(faction.getId() + " is not a vanilla, hence doesnt will always hate you." );
                }
            }
        }
        //log.info("spm_warmode AllModFactionsHateYou --- End");
    }
}

