//package mllhild.spm.util.UAF.old;
//
//import com.fs.starfarer.api.Global;
//import com.fs.starfarer.api.campaign.CampaignFleetAPI;
//import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
//import com.fs.starfarer.api.impl.campaign.intel.MessageIntel;
//import com.fs.starfarer.api.util.Misc;
//
//public class spm_uaf_npcAbyssTravelV2  {
//
//    public boolean isDone() {
//        return false;
//    }
//    public boolean runWhilePaused() {
//        return false;
//    }
//
//    public void PrintTestMessage(){
//        MessageIntel messageTest = new MessageIntel("AllowAbyssTravel Executed");
//        //messageTest.setIcon("");
//        Global.getSector().getCampaignUI().addMessage(messageTest);
//    }
//
//    public void AllowAbyssTravel(){
//        PrintTestMessage();
//        for(CampaignFleetAPI campaignFleetAPI : Global.getSector().getHyperspace().getFleets()){
//            Misc.setFlagWithReason(campaignFleetAPI.getMemoryWithoutUpdate(),MemFlags.MAY_GO_INTO_ABYSS,"spm_uaf",true,100000.0f);
//        }
//    }
//
//    public void advance(float var1) {
//        AllowAbyssTravel();
//    }
//}
