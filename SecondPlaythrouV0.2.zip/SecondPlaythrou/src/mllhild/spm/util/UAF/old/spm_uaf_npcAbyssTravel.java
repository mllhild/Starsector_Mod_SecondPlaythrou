//package mllhild.spm.util.UAF.old;
//
//import com.fs.starfarer.api.Global;
//import com.fs.starfarer.api.campaign.CampaignFleetAPI;
//import com.fs.starfarer.api.campaign.StarSystemAPI;
//import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
//import com.fs.starfarer.api.impl.campaign.procgen.themes.RouteFleetAssignmentAI;
//import com.fs.starfarer.api.util.Misc;
//
//import com.fs.starfarer.api.campaign.LocationAPI;
//import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.RouteData;
//
//public class spm_uaf_npcAbyssTravel extends RouteFleetAssignmentAI {
//
//    public spm_uaf_npcAbyssTravel(CampaignFleetAPI fleet, RouteData route, FleetActionDelegate delegate) {
//        super(fleet, route, delegate);
//        this.fleet = fleet;
//        this.route = route;
//        this.delegate = delegate;
//        giveInitialAssignments();
//    }
//    public spm_uaf_npcAbyssTravel(CampaignFleetAPI fleet, RouteData route) {
//        super(fleet, route);
//        this.fleet = fleet;
//        this.route = route;
//        giveInitialAssignments();
//    }
//
//    @Override
//    protected void giveInitialAssignments() {
//        Misc.setFlagWithReason(fleet.getMemoryWithoutUpdate(),MemFlags.MAY_GO_INTO_ABYSS,"spm_uaf",true,100000.0f);
//        TravelState state = getTravelState(route.getCurrent());
//        LocationAPI conLoc = getLocationForState(route.getCurrent(), state);
//
//        if (fleet.getContainingLocation() != null) {
//            fleet.getContainingLocation().removeEntity(fleet);
//        }
//        conLoc.addEntity(fleet);
//
//        //		Vector2f loc = route.getInterpolatedLocation();
////		fleet.setLocation(loc.x, loc.y);
//        fleet.setFacing((float) Math.random() * 360f);
//
//        pickNext(true);
//    }
//
//    public void GetFleetOnSpawn(){
//
//    }
//
//    // set at game start and on load
//    public void SetFleetBehaviour(){
//        for(CampaignFleetAPI campaignFleetAPI : Global.getSector().getHyperspace().getFleets()){
//            campaignFleetAPI.getMemoryWithoutUpdate().set("$avoidingAbyssalHyperspace", false);
//            campaignFleetAPI.getMemoryWithoutUpdate().set(MemFlags.TEMPORARILY_NOT_AVOIDING_ABYSSAL  , true);
//            campaignFleetAPI.getMemoryWithoutUpdate().set(MemFlags.MAY_GO_INTO_ABYSS, true);
//            //fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_NO_JUMP, true);
//            Misc.setFlagWithReason(campaignFleetAPI.getMemoryWithoutUpdate(),MemFlags.MAY_GO_INTO_ABYSS,"spm_uaf",true,100000.0f);
//        }
//        for(StarSystemAPI starSystemAPI : Global.getSector().getStarSystems()){
//            for(CampaignFleetAPI campaignFleetAPI : starSystemAPI.getFleets()){
//                campaignFleetAPI.getMemoryWithoutUpdate().set(MemFlags.AVOIDING_ABYSSAL_HYPERSPACE , false);
//                campaignFleetAPI.getMemoryWithoutUpdate().set(MemFlags.TEMPORARILY_NOT_AVOIDING_ABYSSAL  , true);
//                campaignFleetAPI.getMemoryWithoutUpdate().set(MemFlags.MAY_GO_INTO_ABYSS, true);
//                Misc.setFlagWithReason(campaignFleetAPI.getMemoryWithoutUpdate(),MemFlags.MAY_GO_INTO_ABYSS,"spm_uaf",true,100000.0f);
//            }
//        }
//    }
//}
