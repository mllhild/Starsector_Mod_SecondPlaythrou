//package mllhild.spm.util.UAF.old;
//import com.fs.starfarer.api.Global;
//import com.fs.starfarer.api.campaign.*;
//import com.fs.starfarer.api.impl.campaign.ids.Factions;
//import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
//import mllhild.spm.SecondPlaythrouModPlugin;
//import mllhild.spm.util.UAF.deephyper.spm_uaf_LocalSpeedBoost;
//import org.apache.log4j.Logger;
//import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;
//import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
//import com.fs.starfarer.api.util.Misc;
//import org.lwjgl.util.vector.Vector2f;
//
//
//
//public class spm_uaf_customPosition {
//    private static final Logger log = Logger.getLogger(SecondPlaythrouModPlugin.class);
//
//    public void MoveUafToDeepHyperspaceTest(){
//        log.info("execute moveStarSystems");
//        for (StarSystemAPI system : Global.getSector().getStarSystems()) {
//            if(system.getBaseName().equalsIgnoreCase("Aoi")){
//                log.info("executed system.getBaseName() Aoi");
//                system.getLocation().set(-100000, 45000);
//                MakeNebulaInDeepHyperspace(-80000, 45000);
//                Global.getSector().addTransientScript(new spm_uaf_LocalSpeedBoost( system.getLocation(),2000,1000,3,"aoi"));
//
//            }
//            if(system.getBaseName().equalsIgnoreCase("Stjarna")){
//                log.info("executed system.getBaseName() Stjarna");
//                system.getLocation().set(-90000, 45000);
//                MakeNebulaInDeepHyperspace(-90000, 45000);
//                Global.getSector().addTransientScript(new spm_uaf_LocalSpeedBoost(system.getLocation(),2000,1000,3,"stjarna"));
//            }
//            if(system.getBaseName().equalsIgnoreCase("Caeli Constellation")){
//                log.info("executed system.getBaseName() Caeli Constellation");
//                system.getLocation().set(-95000, 45000);
//                MakeNebulaInDeepHyperspace(-95000, 45000);
//                Global.getSector().addTransientScript(new spm_uaf_LocalSpeedBoost(system.getLocation(),2000,1000,3,"caeli"));
//            }
//        }
//
//        log.info("executed moveStarSystems");
//    }
//
//
//    public void MakeNebulaInDeepHyperspace(float width, float height){
//        // reference HyperspaceTerrainPlugin
//        log.info("---- MakeNebulaInDeepHyperspace Start ----");
//        log.info("try to get hyperspace");
//        LocationAPI hyper = Global.getSector().getHyperspace();
//        Vector2f loc = new Vector2f(width, height);
//        final int w = 100;
//        final int h = 100;
//
//        StringBuilder string = new StringBuilder();
//        for (int y = h - 1; y >= 0; y--) {
//            for (int x = 0; x < w; x++) {
//                string.append("x");
//            }
//        }
//        log.info(string);
//
//        log.info("try to create TileParams");
//        BaseTiledTerrain.TileParams tileParams = new BaseTiledTerrain.TileParams(string.toString(),
//                        w,
//                        h,
//                        "terrain",
//                        "deep_hyperspace",
//                        1,
//                        1,
//                        null);
//        log.info("try to create SectorEntityToken via hyper.addTerain");
//        CampaignTerrainAPI nebula = (CampaignTerrainAPI) hyper.addTerrain("hyperspace", tileParams);
//
//        log.info("try to set SectorEntityToken ID");
//        nebula.setId("a_new_nebula_Test");
//        log.info("try to set SectorEntityToken location");
//        nebula.setLocation(width, height);
//
//        NebulaEditor editor = new NebulaEditor((BaseTiledTerrain) nebula.getPlugin());
//        editor.regenNoise();
//        editor.noisePrune(0.45f);
//        editor.regenNoise();
//
//        // trial and error is all I can hope for
//        float innerRadius = 0f;
//        float outerRadius = 5000f;
//        float outerClearRadius = 100000f;
//        //log.info("clear donut around system with range in/out " + (outerRadius*2) + " / " + outerClearRadius);
//        editor.clearArc(loc.x, loc.y, outerRadius, outerClearRadius, 0f, 360f);
//        //log.info("clear donut around system with range in/out " + innerRadius + " / " + outerRadius);
//        //editor.clearArc(loc.x, loc.y, innerRadius, outerRadius, 0f, 360f);
//        //final HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin)Misc.getHyperspaceTerrain().getPlugin();
//        //final float minRadius = plugin.getTileSize() * 0.5f;
//        //log.info("NEW HYPER SPace move minRadius " + minRadius );
//        editor.clearArc(loc.x, loc.y, 100, 1000, 0f, 360f, 0.25f);
//        editor.clearArc(loc.x, loc.y, 100, 600, 0f, 360f);
//        //editor.clearArc(loc.x, loc.y, innerRadius, outerRadius, 0f, 360f, 0.25f);
//
//
//
//        //float clearRandom = (float) Math.random() *  359f;
//        //log.info("clear, loc x " + loc.x + 500f * (float) Math.cos(clearRandom) + " , loc y " + loc.y + (float) Math.sin(clearRandom));
//        //editor.clearArc(loc.x + 500f * (float) Math.cos(clearRandom), loc.y + (float) Math.sin(clearRandom), 0f, 450f, 0f, 360f);
//
//
//        //spm_uaf_abyssalLight light = new spm_uaf_abyssalLight();
//        log.info("---- CustomCampaignEntityAPI lightsource ----");
//        CustomCampaignEntityAPI lightsource = hyper.addCustomEntity("spm_lightsource_${Misc.genUID()}", "", "spm_lightsource", Factions.NEUTRAL);
//        log.info("---- lightsource.setLocation(loc.x, loc.y); ----");
//        lightsource.setLocation(loc.x + 0, loc.y + 0);
//        log.info("---- lightsource.setRadius(10000f) ----");
//        lightsource.setRadius(0);
//
//
//
//        //lightsource.getLightColor()
//        //plugin.radius = 10000f
//        //plugin.color = Color(130, 64, 1, 75)
//        log.info("---- MakeNebulaInDeepHyperspace End ----");
//    }
//
//    public void SetFleetBehaviour(){
//        for(CampaignFleetAPI campaignFleetAPI : Global.getSector().getHyperspace().getFleets()){
//            campaignFleetAPI.getMemoryWithoutUpdate().set("$avoidingAbyssalHyperspace", false);
//            campaignFleetAPI.getMemoryWithoutUpdate().set(MemFlags.TEMPORARILY_NOT_AVOIDING_ABYSSAL  , true);
//            campaignFleetAPI.getMemoryWithoutUpdate().set(MemFlags.MAY_GO_INTO_ABYSS, true);
//            //fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_NO_JUMP, true);
//            Misc.setFlagWithReason(campaignFleetAPI.getMemoryWithoutUpdate(),MemFlags.MAY_GO_INTO_ABYSS,"spm_uaf",true,100000.0f);
//        }
//        for(StarSystemAPI starSystemAPI : Global.getSector().getStarSystems()){
//            for(CampaignFleetAPI campaignFleetAPI : starSystemAPI.getFleets()){
//                campaignFleetAPI.getMemoryWithoutUpdate().set(MemFlags.AVOIDING_ABYSSAL_HYPERSPACE , false);
//                campaignFleetAPI.getMemoryWithoutUpdate().set(MemFlags.TEMPORARILY_NOT_AVOIDING_ABYSSAL  , true);
//                campaignFleetAPI.getMemoryWithoutUpdate().set(MemFlags.MAY_GO_INTO_ABYSS, true);
//                Misc.setFlagWithReason(campaignFleetAPI.getMemoryWithoutUpdate(),MemFlags.MAY_GO_INTO_ABYSS,"spm_uaf",true,100000.0f);
//            }
//        }
//    }
//
//}
