//package mllhild.spm.util.UAF.old;
//
//import com.fs.starfarer.api.campaign.CampaignFleetAPI;
//import com.fs.starfarer.api.EveryFrameScript;
//import com.fs.starfarer.api.Global;
//import com.fs.starfarer.api.util.IntervalUtil;
//import mllhild.spm.SecondPlaythrouModPlugin;
//import org.apache.log4j.Logger;
//
//public class spm_uaf_abyssUafSensor implements EveryFrameScript{
//
//    //    Abyss Region
//    //    X > 84000
//    //    Y > 54000
//    //
//    //    Abyss Transition Region (sensor range and profile decays to 25%, AI fleets turn around, blackout of background and cloud layers)
//    //    84000 > X > 82000
//    //    54000 > X > 52000
//    //
//    //    Normal space
//    //    X < 82000
//    //    Y < 52000
//
//    private static final Logger log = Logger.getLogger(SecondPlaythrouModPlugin.class);
//
//    public IntervalUtil fireInterval = new IntervalUtil(60f, 120f);
//
//    @Override
//    public boolean isDone() {return false;}
//
//    @Override
//    public boolean runWhilePaused() {return false;}
//
//    @Override
//    public void advance(float amount) {
//        //log.info("spm_uaf_abyssUafSensor");
//        fireInterval.advance(1f);
//        if (fireInterval.intervalElapsed()){
//            CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
//            if(playerFleet.isInHyperspace()){
//                //log.info("Current Location " + playerFleet.getLocation().getX() + " / " + playerFleet.getLocation().getY() );
//                if(Math.abs((playerFleet.getLocation().getX())) > 84000  || Math.abs((playerFleet.getLocation().getY())) > 54000  ){
//                    playerFleet.setForceNoSensorProfileUpdate(true);
//                    playerFleet.setSensorStrength(1111f);
////                    MessageIntel messageTest = new MessageIntel("Activating Deep Hyperspace Sensors " + playerFleet.getLocation().getX() + " / " + playerFleet.getLocation().getY() , new Color(200,0,200));
////                    Global.getSector().getCampaignUI().addMessage(messageTest);
//                }else {
//                    playerFleet.setForceNoSensorProfileUpdate(false);
//                    log.info(playerFleet.getSensorProfile());
//                }
//            }else {
//                playerFleet.setForceNoSensorProfileUpdate(false);
//                log.info(playerFleet.getSensorProfile());
//            }
//        }
//    }
//}
