//package mllhild.spm.util.UAF.old;
//
//import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
//
////    A strait copy from RATs Exotech
////    seems like a lot of work for getting the clouds to storm and slow you down
////    also makes them static terrain, but likely a lot more vram efficient than what Im doing
//
//public class spm_uaf_terrainDeepHyperspace extends HyperspaceTerrainPlugin {
////    private String id = Misc.genUID();
////
////    private transient SpriteAPI background = Global.getSettings().getSprite("graphics/backgrounds/uaf_bg.jpg");
////    private transient SpriteAPI vignette = Global.getSettings().getSprite("graphics/fx/uaf_vignette.png");
////    private transient SpriteAPI halo = null;
////
////    private float range = 1300f;
////    private float levelMinRange = 200f;
////    private float levelMaxRange = 1300f;
////    private float centerClearRadius = 350f;
////
////    @Override
////    public EnumSet<CampaignEngineLayers> getActiveLayers() {
////        EnumSet<CampaignEngineLayers> combined = super.getActiveLayers();
////        combined.addAll(EnumSet.of(CampaignEngineLayers.TERRAIN_2, CampaignEngineLayers.ABOVE));
////        return combined;
////    }
////
////    @Override
////    public void render(CampaignEngineLayers layer, ViewportAPI viewport) {
////        super.render(layer, viewport);
////
////        float level = getLevel();
////        if (level <= 0) return;
////
////        if (background == null || vignette == null) {
////            background = Global.getSettings().getSprite("graphics/backgrounds/uaf_bg.jpg");
////            vignette = Global.getSettings().getSprite("graphics/fx/uaf_vignette.png");
////        }
////
////        if (layer == CampaignEngineLayers.TERRAIN_2) {
////            float width = viewport.getVisibleWidth();
////            float height = viewport.getVisibleHeight();
////
////            float x = viewport.getLLX();
////            float y = viewport.getLLY();
////
////            background.setSize(width, width);
////            background.setAlphaMult(level * 0.2f);
////            background.render(x, y);
////        }
////
////        if (layer == CampaignEngineLayers.ABOVE) {
////            CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
////            if (entity.getContainingLocation() == playerFleet.getContainingLocation()) {
////                float offset = 400f;
////
////                vignette.setAlphaMult(0.5f * level);
////                vignette.setSize(viewport.getVisibleWidth() + offset, viewport.getVisibleHeight() + offset);
////                vignette.render(viewport.getLLX() - (offset / 2), viewport.getLLY() - (offset / 2));
////            }
////        }
////    }
////
////    private float getLevel() {
////        float distance = MathUtils.getDistance(Global.getSector().getPlayerFleet(), entity);
////        float level = (distance - levelMinRange) / (levelMaxRange - levelMinRange);
////        level = Math.max(0f, Math.min(1f, level));
////        return 1 - level;
////    }
////
////    @Override
////    public void renderOnMap(float factor, float alphaMult) {
////    }
////
////    @Override
////    public void renderOnRadar(Vector2f radarCenter, float factor, float alphaMult) {
////        super.renderOnRadar(radarCenter, factor, alphaMult);
////    }
////
////    @Override
////    public boolean stacksWithSelf() {
////        return true;
////    }
////
////    @Override
////    public float getRenderRange() {
////        return 10000000f;
////    }
////
////    @Override
////    public void advance(float amount) {
////        LocationAPI currentSystem = entity.getContainingLocation();
////        if (currentSystem == null) return;
////        if (Global.getSector().getPlayerFleet().getContainingLocation() != currentSystem) return;
////
////        if (isInClouds(Global.getSector().getPlayerFleet())) {
////            for (FleetMemberAPI member : Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy()) {
////                if (member.getRepairTracker().getCR() > 0f) {
////                    member.getRepairTracker().setCR(member.getRepairTracker().getCR() - 0.010f * amount);
////                }
////            }
////        }
////
////        super.advance(amount);
////    }
////
////    @Override
////    public Color getRenderColor() {
////        return new Color(130, 64, 1);
////    }
////
////    public void save() {
////        params.tiles = null;
////        savedTiles = encodeTiles(tiles);
////
////        savedActiveCells.clear();
////
////        for (int i = 0; i < activeCells.length; i++) {
////            for (int j = 0; j < activeCells[0].length; j++) {
////                CellStateTracker curr = activeCells[i][j];
////                if (curr != null && isTileVisible(i, j)) {
////                    savedActiveCells.add(curr);
////                }
////            }
////        }
////    }
////
////    @Override
////    public void applyEffect(SectorEntityToken entity, float days) {
////        if (entity == null) return;
////        LocationAPI currentSystem = entity.getContainingLocation();
////        if (Global.getSector().getPlayerFleet().getContainingLocation() != currentSystem) return;
////
////        if (entity instanceof CampaignFleetAPI) {
////            CampaignFleetAPI fleet = (CampaignFleetAPI) entity;
////            boolean inCloud = this.isInClouds(fleet);
////            int[] tile = getTilePreferStorm(fleet.getLocation(), fleet.getRadius());
////            CellStateTracker cell = null;
////            if (tile != null) {
////                cell = activeCells[tile[0]][tile[1]];
////            }
////
////            if (isInClouds(fleet)) {
////                if (cell != null && cell.isSignaling() && cell.signal < 0.2f) {
////                    cell.signal = 0f;
////                }
////
////                AbilityPlugin goDark = Global.getSector().getPlayerFleet().getAbility(Abilities.GO_DARK);
////                boolean goDarkActive = false;
////
////                if (goDark != null) {
////                    goDarkActive = goDark.isActive();
////                }
////
////                if (cell != null && cell.isStorming() && !Misc.isSlowMoving(fleet) && !goDarkActive) {
////                    applyStormStrikes(cell, fleet, days);
////                }
////            }
////        }
////    }
////
////    @Override
////    public String getModId() {
////        return super.getModId() + id;
////    }
////
////    @Override
////    public void createTooltip(TooltipMakerAPI tooltip, boolean expanded) {
////        CampaignFleetAPI player = Global.getSector().getPlayerFleet();
////        if (player.getContainingLocation() != entity.getContainingLocation()) return;
////
////        boolean inCloud = this.isInClouds(player);
////
////        tooltip.addTitle(getTerrainName());
////        tooltip.addSpacer(5f);
////
////        tooltip.addPara("An intensily radiated dust formation left from some kind of catastrophic event. Staying inside will rapidly damage all ships within the fleet. Avoid extended stay at all cost.",
////                0f, Misc.getTextColor(), Misc.getHighlightColor(), "damage", "Avoid extended stay at all cost");
////
////        tooltip.addSpacer(5f);
////    }
////
////    @Override
////    public String getTerrainName() {
////        CampaignFleetAPI player = Global.getSector().getPlayerFleet();
////        boolean inCloud = this.isInClouds(player);
////
////        return inCloud ? "Ionised Dust" : "";
////    }
////
////    @Override
////    public Color getNameColor() {
////        return new Color(247, 173, 12);
////    }
////
////    public boolean isInStorm(SectorEntityToken entity) {
////        int[] tile = getTilePreferStorm(entity.getLocation(), entity.getRadius());
////        CellStateTracker cell = null;
////        if (tile != null) {
////            cell = activeCells[tile[0]][tile[1]];
////        }
////        return cell != null && cell.isStorming();
////    }
////
////    @Override
////    public boolean isTooltipExpandable() {
////        return false;
////    }
////
////    @Override
////    public String getTerrainId() {
////        return super.getTerrainId() + id;
////    }
////
////    @Override
////    public boolean hasAIFlag(Object flag) {
////        return false;
////    }
////
////    @Override
////    public boolean hasAIFlag(Object flag, CampaignFleetAPI fleet) {
////        return flag == TerrainAIFlags.MOVES_FLEETS;
////    }
//}
