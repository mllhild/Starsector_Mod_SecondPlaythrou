package mllhild.spm.util.UAF.deephyper;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import mllhild.spm.SecondPlaythrouModPlugin;
import org.apache.log4j.Logger;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

public class spm_uaf_abyssbeacon implements EveryFrameScript{

    //    Abyss Region
    //    X > 84000
    //    Y > 54000
    //
    //    Abyss Transition Region (sensor range and profile decays to 25%, AI fleets turn around, blackout of background and cloud layers)
    //    84000 > X > 82000
    //    54000 > X > 52000
    //
    //    Normal space
    //    X < 82000
    //    Y < 52000
    public spm_uaf_abyssbeacon(Vector2f center, float radiusBoostStart, float radiusBoostFull, float boostMult, String modID){
        this.bonusCore = center;
        this.radiusBoostStart = radiusBoostStart;
        this.radiusBoostFull = radiusBoostFull;
        this.burnModMulty = boostMult;
        this.modID = modID;
        log.info("spm_uaf_uafLocalSpeedBoost " + center.x + " / "+ center.y);
        log.info("spm_uaf_uafLocalSpeedBoost " + radiusBoostStart);
        log.info("spm_uaf_uafLocalSpeedBoost " + boostMult);
    };

    private static final Logger log = Logger.getLogger(SecondPlaythrouModPlugin.class);

    public IntervalUtil fireInterval = new IntervalUtil(60f, 120f);

    public Vector2f bonusCore = new Vector2f(-90000,45000);
    public float radiusBoostStart;
    public float radiusBoostFull;
    float burnModMulty = 1f;
    String modID = "";
    public boolean removeModFromAll = false;

    @Override
    public boolean isDone() {return false;}

    @Override
    public boolean runWhilePaused() {return false;}

    @Override
    public void advance(float amount) {

        fireInterval.advance(1f);
        if (fireInterval.intervalElapsed()){
            CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
            if(playerFleet.isInHyperspace()){
                if(MathUtils.getDistance(playerFleet.getLocation(),bonusCore) < 5000){
                    removeModFromAll = true;
                    for(CampaignFleetAPI fleet : Global.getSector().getHyperspace().getFleets()){
                        float distance = MathUtils.getDistance(fleet.getLocation(),bonusCore);
                        if(distance < radiusBoostStart){
                            float burnModMultyTemp = burnModMulty;
                            if (distance > radiusBoostFull) {burnModMultyTemp = 1 + ((radiusBoostStart - distance)/(radiusBoostStart - radiusBoostFull)) * (burnModMulty-1);}
                            fleet.getStats().getFleetwideMaxBurnMod().modifyMult("spm_uaf_localSpeedBoost_Multy_"+modID, burnModMultyTemp, "Abyss Beacon Speed increase");
                            fleet.getStats().getSensorRangeMod().modifyMult("spm_uaf_localSensorBoost_Multy_"+modID, burnModMultyTemp, "Abyss Beacon Sensor increase");
                            fleet.getStats().getSensorProfileMod().modifyMult("spm_uaf_localProfileBoost_Multy_"+modID, burnModMultyTemp, "Abyss Beacon Profile increase");
                        }else {
                            fleet.getStats().getFleetwideMaxBurnMod().unmodifyMult("spm_uaf_localSpeedBoost_Multy_"+modID);
                            fleet.getStats().getSensorRangeMod().unmodifyMult("spm_uaf_localSensorBoost_Multy_"+modID);
                            fleet.getStats().getSensorProfileMod().unmodifyMult("spm_uaf_localProfileBoost_Multy_"+modID);
                        }
                    }
                } else if (removeModFromAll) {
                    for(CampaignFleetAPI fleet : Global.getSector().getHyperspace().getFleets()){
                        fleet.getStats().getFleetwideMaxBurnMod().unmodifyMult("spm_uaf_localSpeedBoost_Multy_"+modID);
                        fleet.getStats().getSensorRangeMod().unmodifyMult("spm_uaf_localSensorBoost_Multy_"+modID);
                        fleet.getStats().getSensorProfileMod().unmodifyMult("spm_uaf_localProfileBoost_Multy_"+modID);
                    }


                }
            }
        }
    }
}
