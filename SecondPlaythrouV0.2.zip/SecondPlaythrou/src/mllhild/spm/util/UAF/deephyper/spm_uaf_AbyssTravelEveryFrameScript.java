package mllhild.spm.util.UAF.deephyper;

import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import mllhild.spm.SecondPlaythrouModPlugin;
import org.apache.log4j.Logger;

public class spm_uaf_AbyssTravelEveryFrameScript implements EveryFrameScript {

//    Abyss Region
//    X > 84000
//    Y > 54000
//
//    Abyss Transition Region (sensor range and profile decays to 25%, AI fleets turn around, blackout of background and cloud layers)
//    84000 > X > 82000
//    54000 > X > 52000
//
//    Normal space
//    X < 82000
//    Y < 52000
    private static final Logger log = Logger.getLogger(SecondPlaythrouModPlugin.class);
    public IntervalUtil fireInterval = new IntervalUtil(120f, 240f);

    @Override
    public boolean isDone() {return false;}

    @Override
    public boolean runWhilePaused() {return false;}

    @Override
    public void advance(float amount) {
        //log.info("SPM spm_uaf_AbyssTravelEveryFrameScript advance Start");
        //log.info("SPM spm_uaf_AbyssTravelEveryFrameScript fireInterval.getElapsed =" + fireInterval.getElapsed());
        fireInterval.advance(1f);

        if (fireInterval.intervalElapsed()){

          //  log.info("SPM spm_uaf_AbyssTravelEveryFrameScript advance fireInterval.intervalElapsed() = true ------------------------------");
//            MessageIntel messageTest = new MessageIntel("AllowAbyssTravel Executed " + Global.getSector().getClock().getDay());
//            Global.getSector().getCampaignUI().addMessage(messageTest);
            for(CampaignFleetAPI campaignFleetAPI : Global.getSector().getHyperspace().getFleets()){
                Misc.setFlagWithReason(campaignFleetAPI.getMemoryWithoutUpdate(), MemFlags.MAY_GO_INTO_ABYSS,"spm_uaf",true,100000.0f);
            }
        }
//        if (Global.getSector().isPaused()) {
//            return;
//        }
//        timer += amount;


//        if (timer >= INTERVAL) {
//            MessageIntel messageTest = new MessageIntel("AllowAbyssTravel Executed");
//            Global.getSector().getCampaignUI().addMessage(messageTest);
//            for(CampaignFleetAPI campaignFleetAPI : Global.getSector().getHyperspace().getFleets()){
//                Misc.setFlagWithReason(campaignFleetAPI.getMemoryWithoutUpdate(), MemFlags.MAY_GO_INTO_ABYSS,"spm_uaf",true,100000.0f);
//            }
//            timer = 0f;
//        }
        //log.info("SPM spm_uaf_AbyssTravelEveryFrameScript advance End");

    }
}