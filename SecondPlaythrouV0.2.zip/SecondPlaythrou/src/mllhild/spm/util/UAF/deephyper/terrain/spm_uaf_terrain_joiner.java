package mllhild.spm.util.UAF.deephyper.terrain;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignEngineLayers;
import com.fs.starfarer.api.combat.ViewportAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.impl.campaign.BaseCustomEntityPlugin;

import java.awt.*;

public class spm_uaf_terrain_joiner extends BaseCustomEntityPlugin{
    public float radius = 5000f;
    public float width = 8000f;
    public float height = 8000f;
    public Color color = new Color(255,255,255,255);
    public SpriteAPI spriteAPI;

    @Override
    public void advance(float amount) {
        super.advance(amount);
        initSpritesIfNull();
    }

    public void initSpritesIfNull() {
        if (spriteAPI == null) {
            if (entity.getStarSystem() != null) { color = new Color(255,255,255,255);}
            spriteAPI = Global.getSettings().getSprite("spm_terrain", "spm_uaf_joiner");
        }
    }

    @Override
    public float getRenderRange() {
        return super.getRenderRange() + radius * 1.1f;
    }

    @Override
    public void render(CampaignEngineLayers layer, ViewportAPI viewport) {
        super.render(layer, viewport);

        initSpritesIfNull();

        if (spriteAPI == null) {spriteAPI = Global.getSettings().getSprite("spm_terrain", "spm_uaf_joiner");}

        spriteAPI.setAlphaMult(1f);
        spriteAPI.setColor(color);
        spriteAPI.setSize(width, height);
        //spriteAPI.setAdditiveBlend();
        spriteAPI.setNormalBlend();
        spriteAPI.renderAtCenter(entity.getLocation().x, entity.getLocation().y);
    }
}
