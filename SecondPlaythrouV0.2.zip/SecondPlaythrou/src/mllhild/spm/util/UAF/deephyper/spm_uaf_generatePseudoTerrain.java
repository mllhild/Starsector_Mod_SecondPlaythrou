package mllhild.spm.util.UAF.deephyper;


import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.CustomCampaignEntityAPI;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import mllhild.spm.SecondPlaythrouModPlugin;
import org.apache.log4j.Logger;
import org.lwjgl.util.vector.Vector2f;

public class spm_uaf_generatePseudoTerrain {
    private static final Logger log = Logger.getLogger(SecondPlaythrouModPlugin.class);

    //    Abyss Region
    //    X > 84000
    //    Y > 54000
    //
    //    Abyss Transition Region (sensor range and profile decays to 25%, AI fleets turn around, blackout of background and cloud layers)
    //    84000 > X > 82000
    //    54000 > X > 52000
    //
    //    Normal space
    //    X < 82000
    //    Y < 52000

    public void MigrateUafToAbyss(float x, float y){
        AddTerrainAsLightSource(x - 2000 ,y - 0 ,"spm_uaf_joiner");
        MoveAoi(x,y);
        MoveCaeli(x - 4000 ,y + 600);
        MoveStjarna(x - 5000 ,y - 1200);
        MovePS(x - 2500 ,y - 1500);
    }
    

    public void MoveAoi(float x, float y){
        for (StarSystemAPI system : Global.getSector().getStarSystems()) {
            if(system.getBaseName().equalsIgnoreCase("Aoi")){
                log.info("---- MoveAoi ---- " + " X " + x + " Y " + y);
                system.getLocation().set(x, y);
                system.getHyperspaceAnchor().setLocation(x,y);
                AddSpeedBoostBeacon( system.getLocation(),2000,1500,3,"aoi");
                AddTerrainAsLightSource(x,y,"spm_aoi_bg");
                AddTerrainAsLightSource(x,y,"spm_aoi_cloud_back");
                AddTerrainAsLightSource(x,y,"spm_aoi_cloud_front");
            }
        }
    }

    public void MoveCaeli(float x, float y){
        for (StarSystemAPI system : Global.getSector().getStarSystems()) {
            if(system.getBaseName().equalsIgnoreCase("Caeli Constellation")){
                log.info("---- MoveCaeli ---- " + " X " + x + " Y " + y);
                system.getLocation().set(x, y);
                system.getHyperspaceAnchor().setLocation(x,y);
                AddSpeedBoostBeacon( system.getLocation(),1800,1200,3,"caeli");
                AddTerrainAsLightSource(x,y,"spm_caeli_bg");
                AddTerrainAsLightSource(x,y,"spm_caeli_cloud_back");
                AddTerrainAsLightSource(x,y,"spm_caeli_cloud_front");
            }
        }
    }

    public void MoveStjarna(float x, float y){
        for (StarSystemAPI system : Global.getSector().getStarSystems()) {
            if(system.getBaseName().equalsIgnoreCase("Stjarna")){
                log.info("---- MoveStjarna ---- " + " X " + x + " Y " + y);
                system.getLocation().set(x, y);
                system.getHyperspaceAnchor().setLocation(x,y);
                AddSpeedBoostBeacon( system.getLocation(),1800,1200,3,"stjarna");
                AddTerrainAsLightSource(x,y,"spm_stjarna_bg");
                AddTerrainAsLightSource(x,y,"spm_stjarna_cloud_back");
                AddTerrainAsLightSource(x,y,"spm_stjarna_cloud_front");
            }
        }
    }

    public void MovePS(float x, float y){
        for (StarSystemAPI system : Global.getSector().getStarSystems()) {
            if(system.getBaseName().equalsIgnoreCase("PlayerSystem")){
                log.info("---- MovePlayerSystem ---- " + " X " + x + " Y " + y);
                system.getLocation().set(x, y);
                system.getHyperspaceAnchor().setLocation(x,y);
                AddSpeedBoostBeacon( system.getLocation(),1200,800,3,"ps");
                AddTerrainAsLightSource(x,y,"spm_ps_bg");
                AddTerrainAsLightSource(x,y,"spm_ps_cloud_back");
                AddTerrainAsLightSource(x,y,"spm_ps_cloud_front");
            }
        }
    }

    // see types in data/config/custom_entities.json   Example: "spm_aoi_bg"
    public void AddTerrainAsLightSource(float x, float y, String type){
        log.info("---- AddTerrainAsLightSource ---- " + " type "  + type + " X " + x + " Y " + y);
        LocationAPI hyper = Global.getSector().getHyperspace();
        // pulls from data/config/custom_entities.json
        CustomCampaignEntityAPI customCampaignEntityAPI = hyper.addCustomEntity("spm_uaf_${Misc.genUID()}", "", type, Factions.NEUTRAL);
        customCampaignEntityAPI.setLocation(x, y);
        customCampaignEntityAPI.setRadius(0);
    }
    public void AddTerrainAsLightSource(SectorEntityToken entityToken, String type){
        log.info("---- AddTerrainAsLightSource ---- " + " type "  + type + " X " + entityToken.getLocation().getX() + " Y " + entityToken.getLocation().getY());
        LocationAPI hyper = Global.getSector().getHyperspace();
        // pulls from data/config/custom_entities.json
        CustomCampaignEntityAPI customCampaignEntityAPI = hyper.addCustomEntity("spm_uaf_${Misc.genUID()}", "", type, Factions.NEUTRAL);
        customCampaignEntityAPI.setLocation(entityToken.getLocation().getX(), entityToken.getLocation().getY());
        customCampaignEntityAPI.setRadius(0);
        // doesnt seem to work
        customCampaignEntityAPI.setCircularOrbit(entityToken, 50, 1, 10);
    }

    public void AddSpeedBoostBeacon(Vector2f center, float radiusBoostStart, float radiusBoostFull, float boostMult, String modID){
        log.info("---- AddSpeedBoostBeacon ---- " + " idSuf "  + modID + " X " + center.x + " Y " + center.y + " rStart " + radiusBoostStart + " rFull " + radiusBoostFull + " mult " + boostMult);
        Global.getSector().addTransientScript(new spm_uaf_abyssbeacon(center ,radiusBoostStart,radiusBoostFull,boostMult,modID));
    }

}
