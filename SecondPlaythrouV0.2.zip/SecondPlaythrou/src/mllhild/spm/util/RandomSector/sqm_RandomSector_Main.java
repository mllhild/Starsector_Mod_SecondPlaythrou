package mllhild.spm.util.RandomSector;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
import com.fs.starfarer.api.util.Misc;
import com.sun.org.apache.bcel.internal.generic.PUSH;
import lunalib.lunaSettings.LunaSettings;
import mllhild.spm.SecondPlaythrouModPlugin;
import org.apache.log4j.Logger;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.*;

import java.util.Arrays;
import java.util.List;

public class sqm_RandomSector_Main {
    private static final Logger log = Logger.getLogger(SecondPlaythrouModPlugin.class);

    public void LunaStart() {
        log.info("Secomnd Playthrou");
        log.info("Get Luna Settings Data");

        float sectorWidth = MagicVariables.getSectorWidth();
        float sectorHeight = MagicVariables.getSectorHeight();

        Boolean moveAllInhabitedSystemsToCore = LunaSettings.getBoolean("SecondPlaythrou", "moveAllInhabitedSystemsToCore");
        Boolean randomAllSystempositions = LunaSettings.getBoolean("SecondPlaythrou", "randomAllSystempositions");
        Boolean random_coreSystems = LunaSettings.getBoolean("SecondPlaythrou", "random_coreSystems");
        Boolean random_rimSystemInhabited = LunaSettings.getBoolean("SecondPlaythrou", "random_rimSystemInhabited");

        // core systems to be excluded from movement
        String random_coreSystem_Blacklist_string = LunaSettings.getString("SecondPlaythrou", "random_coreSystem_Blacklist");
        List<String> random_coreSystem_Blacklist;
        if (random_coreSystem_Blacklist_string != null)
            random_coreSystem_Blacklist = Arrays.asList(random_coreSystem_Blacklist_string.trim().split("\\s*,\\s*")); // Trims spaces around commas
        else
            random_coreSystem_Blacklist = Arrays.asList(new String[0]); // Handle null case gracefully

        // rim systems to be excluded from movement
        String random_rimSystem_Blacklist_string = LunaSettings.getString("SecondPlaythrou", "random_rimSystem_Blacklist");
        List<String> random_rimSystem_Blacklist;
        if (random_rimSystem_Blacklist_string != null)
            random_rimSystem_Blacklist = Arrays.asList(random_rimSystem_Blacklist_string.trim().split("\\s*,\\s*")); // Trims spaces around commas
        else
            random_rimSystem_Blacklist = Arrays.asList(new String[0]); // Handle null case gracefully



        log.info("Second Playthrou - All System Names for Reference");
        for(StarSystemAPI system1 : Global.getSector().getStarSystems())
            log.info(system1.getBaseName() + "  Location: " + system1.getLocation().getX() + " " + system1.getLocation().getY());
        log.info("------ End --------");

        log.info("Second Playthrou - Blacklisted Systems");
        log.info("Core");
        for(String system1 : random_coreSystem_Blacklist)
        {
            Boolean foundMatchingSystem = false;
            for(StarSystemAPI system2 : Global.getSector().getStarSystems())
                if(system1.equals(system2.getBaseName()))
                {foundMatchingSystem = true; log.info("+"+system1+"+ system found"); break;}
            if(!foundMatchingSystem)
                log.info("+"+system1+"+ no system with that name found");
        }
        log.info("Rim");
        for(String system1 : random_rimSystem_Blacklist)
        {
            Boolean foundMatchingSystem = false;
            for(StarSystemAPI system2 : Global.getSector().getStarSystems())
                if(system1.equals(system2.getBaseName()))
                {foundMatchingSystem = true; log.info("+"+system1+"+ system found"); break;}
            if(!foundMatchingSystem)
                log.info("+"+system1+"+ no system with that name found");
        }

        log.info("------ End --------");

        int randomCore_minDistanceInhabited = LunaSettings.getInt("SecondPlaythrou", "randomCore_minDistanceInhabited");
        int randomCore_minDistanceUninhabited = LunaSettings.getInt("SecondPlaythrou", "randomCore_minDistanceUninhabited");
        int randomCore_outerCoreLimit = LunaSettings.getInt("SecondPlaythrou", "randomCore_outerCoreLimit");
        int randomCore_innerCoreLimit = LunaSettings.getInt("SecondPlaythrou", "randomCore_innerCoreLimit");


        log.info("Start System Moving");

        log.info("randomAllSystempositions " + randomAllSystempositions);
        if(randomAllSystempositions){
            for(StarSystemAPI system1 : Global.getSector().getStarSystems()){
                log.info(system1.getBaseName());
                if(random_coreSystem_Blacklist.contains(system1.getBaseName())){log.info("random_coreSystem_Blacklist");continue;}

                if(random_rimSystem_Blacklist.contains(system1.getBaseName())){log.info("random_rimSystem_Blacklist");continue;}
                RandomiseSystemPosition(system1,sectorHeight,sectorWidth,randomCore_minDistanceUninhabited,0);
            }
        }

        log.info("moveAllInhabitedSystemsToCore " + moveAllInhabitedSystemsToCore );
        if(moveAllInhabitedSystemsToCore){
            for(StarSystemAPI system1 : Global.getSector().getStarSystems()){
                if(random_coreSystem_Blacklist.contains(system1.getBaseName()))
                    continue;
                if(random_rimSystem_Blacklist.contains(system1.getBaseName()))
                    continue;
                if(system1.getLocation().lengthSquared() > (randomCore_outerCoreLimit*randomCore_outerCoreLimit))
                    for(PlanetAPI planet : system1.getPlanets())
                        if(planet.getMarket() != null)
                            if(planet.getMarket().getSize() > 2) {
                                RandomiseSystemPositionCore(system1,randomCore_outerCoreLimit,randomCore_innerCoreLimit,randomCore_minDistanceInhabited,0);
                                break;}
            }
        }
        log.info("random_coreSystems " + random_coreSystems);
        if(random_coreSystems){
            for(StarSystemAPI system1 : Global.getSector().getStarSystems()){
                if(random_coreSystem_Blacklist.contains(system1.getBaseName()))
                    continue;
                if(random_rimSystem_Blacklist.contains(system1.getBaseName()))
                    continue;
                if(system1.getLocation().lengthSquared() < (randomCore_outerCoreLimit*randomCore_outerCoreLimit))
                    RandomiseSystemPositionCore(system1,randomCore_outerCoreLimit,randomCore_innerCoreLimit,randomCore_minDistanceInhabited,0);
            }
        }

        log.info("random_rimSystemInhabited " + random_rimSystemInhabited);
        if(random_rimSystemInhabited){
            for(StarSystemAPI system1 : Global.getSector().getStarSystems()) {
                if(random_coreSystem_Blacklist.contains(system1.getBaseName()))
                    continue;
                if(random_rimSystem_Blacklist.contains(system1.getBaseName()))
                    continue;
                if (system1.getLocation().lengthSquared() > (randomCore_outerCoreLimit * randomCore_outerCoreLimit))
                    for (PlanetAPI planet : system1.getPlanets())
                        if (planet.getMarket().getSize() > 2) {
                            RandomiseSystemPositionRim(system1, sectorHeight, sectorWidth, randomCore_outerCoreLimit, randomCore_minDistanceInhabited, 0);
                            break;
                        }
            }
        }

        log.info("------ End ------");

    }

    public void MoveSystem(StarSystemAPI system, float height, float width){
        system.getLocation().set(width,height);
        system.getHyperspaceAnchor().setLocation(width,height);
        log.info("Moved Systen " + system.getBaseName() + " to " + height + " " + width);
        cleanup(system);
    }
    public void cleanup(final StarSystemAPI system) {
        HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
        NebulaEditor editor = new NebulaEditor((BaseTiledTerrain)plugin);
        float minRadius = plugin.getTileSize() * 0.5f;
        float radius = system.getMaxRadiusInHyperspace();
        editor.clearArc(system.getLocation().x, system.getLocation().y, 0.0f, radius + minRadius * 0.5f, 0.0f, 360.0f);
        editor.clearArc(system.getLocation().x, system.getLocation().y, 0.0f, radius + minRadius, 0.0f, 360.0f, 0.25f);
    }

    public void RandomiseSystemPosition(StarSystemAPI system, float sectorHeight, float sectorWidth, int randomCore_minDistanceUninhabited, int counter){
        if(counter>10) // emergency break
        { log.info(system.getBaseName() + " failed to find location -----------------------------");
            return;}
        counter++;
        float height = (float) ((Math.random()-0.5) * 2 * sectorHeight);
        float width = (float) ((Math.random()-0.5) * 2 * sectorWidth);
        float minDistance = 100000;
        for(StarSystemAPI system1 : Global.getSector().getStarSystems()){
            if(system1.getId().equals(system.getId()))
                continue;
            float distance =   Distance(system1.getHyperspaceAnchor().getLocation(), new Vector2f(width,height));
            if(distance<minDistance)
                minDistance = distance;
        }
        log.info(height + " " + width + " " + minDistance + " " +randomCore_minDistanceUninhabited);
        if(minDistance < randomCore_minDistanceUninhabited)
            RandomiseSystemPosition(system, sectorHeight, sectorWidth, randomCore_minDistanceUninhabited, counter);
        else
            MoveSystem(system,height,width);
    }

    public void RandomiseSystemPositionCore(StarSystemAPI system, int outerCoreLimit, int innerCoreLimit, int randomCore_minDistanceInhabited, int counter){
        if(counter>10) // emergency break
        { log.info(system.getBaseName() + " failed to find location -----------------------------");
            return;}
        counter++;
        float radius = (float) ((outerCoreLimit - innerCoreLimit) * Math.random() + innerCoreLimit);
        float angle = (float) Math.random() * 360;

        float height = radius * (float) Math.cos(angle);
        float width = radius * (float) Math.sin(angle);
        float minDistance = 100000;
        for(StarSystemAPI system1 : Global.getSector().getStarSystems()){
            if(system1.getId().equals(system.getId()))
                continue;
            float distance =   Distance(system1.getHyperspaceAnchor().getLocation(), new Vector2f(width,height));
            //log.info("distance " + distance + " " + system1.getHyperspaceAnchor().getLocation().getX() + " " + system1.getHyperspaceAnchor().getLocation().getY() + " " + height + " " + height);
            if(distance<minDistance)
                minDistance = distance;
        }
        log.info(height + " " + width + " " + minDistance + " " +randomCore_minDistanceInhabited);
        if(minDistance < randomCore_minDistanceInhabited)
            RandomiseSystemPositionCore(system, outerCoreLimit, innerCoreLimit, randomCore_minDistanceInhabited, counter);
        else
            MoveSystem(system,height,width);
    }

    public void RandomiseSystemPositionRim(StarSystemAPI system, float sectorHeight, float sectorWidth, int outerCoreLimit,  int randomCore_minDistanceUninhabited, int counter){
        if(counter>10) // emergency break
        { log.info(system.getBaseName() + " failed to find location -----------------------------");
            return;}
        counter++;
        float height = (float) ((Math.random()-0.5) * 2 * sectorHeight);
        float width = (float) ((Math.random()-0.5) * 2 * sectorWidth);
        float minDistance = 100000;
        for(StarSystemAPI system1 : Global.getSector().getStarSystems()){
            if(system1.getId().equals(system.getId()))
                continue;
            float distance =   Distance(system1.getHyperspaceAnchor().getLocation(), new Vector2f(width,height));
            if(distance<minDistance)
                minDistance = distance;
        }
        log.info(height + " " + width + " " + minDistance + " " +randomCore_minDistanceUninhabited);
        if(minDistance < randomCore_minDistanceUninhabited || (outerCoreLimit*outerCoreLimit) < (height*height + width*width))
            RandomiseSystemPositionRim(system, sectorHeight, sectorWidth, outerCoreLimit, randomCore_minDistanceUninhabited, counter);
        else
            MoveSystem(system,height,width);
    }


    public void RandomizeUninhabitedCoreworlds(){
        for(StarSystemAPI system : Global.getSector().getStarSystems()){
            for(PlanetAPI planet : system.getPlanets()){
                if(planet.getMarket().getSize() > 2)
                    continue;
                for(MarketConditionAPI condition : planet.getMarket().getConditions())
                    planet.getMarket().removeCondition(condition.getId());

                // add random conditions
                

            }
        }
    }

    public float Distance(Vector2f v1, Vector2f v2){
        return (float)Math.sqrt( (v1.x-v2.x)*(v1.x-v2.x) + (v1.y-v2.y)*(v1.y-v2.y) );
    }
}
