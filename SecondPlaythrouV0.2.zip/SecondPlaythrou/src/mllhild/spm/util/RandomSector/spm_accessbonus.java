package mllhild.spm.util.RandomSector;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import lunalib.lunaSettings.LunaSettings;

public class spm_accessbonus {

    public void GiveAccessBonus(){


    }
    public void AddAccessBonusToPlanets(){
        Boolean accessbonusInhabited = true;
        Boolean accessbonusallAll = true;
        for(StarSystemAPI system: Global.getSector().getStarSystems()){
            for(PlanetAPI planet: system.getPlanets()){
                MarketAPI market = planet.getMarket();
                if (market == null)
                    continue;
                if(market.getSize() == 1)
                    if(!accessbonusallAll)
                        continue;
                if(market.getSize() > 1)
                    if(!accessbonusInhabited)
                        continue;

                float distance = (float) Math.sqrt( Math.pow(system.getLocation().getX(), 2) + Math.pow(system.getLocation().getY(), 2) );

                if (distance < 5000) {
                    // Nothing to do
                } else if (distance < 10000) {
                    market.addCondition("spm_access_10");
                } else if (distance < 20000) {
                    market.addCondition("spm_access_20");
                } else if (distance < 30000) {
                    market.addCondition("spm_access_30");
                } else if (distance < 40000) {
                    market.addCondition("spm_access_40");
                } else if (distance < 50000) {
                    market.addCondition("spm_access_50");
                } else if (distance < 60000) {
                    market.addCondition("spm_access_60");
                } else if (distance < 70000) {
                    market.addCondition("spm_access_70");
                }
            }
        }
    }

}
