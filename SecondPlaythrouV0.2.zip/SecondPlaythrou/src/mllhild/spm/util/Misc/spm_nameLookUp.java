package mllhild.spm.util.Misc;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.ai.AbilityAIPlugin;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.AbilityPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.rulecmd.AddRemoveCommodity;
import com.fs.starfarer.api.plugins.SurveyPlugin;
import com.fs.starfarer.api.util.Misc;
import mllhild.spm.SecondPlaythrouModPlugin;
import org.apache.log4j.Logger;

import java.util.List;
import java.util.Map;

public class spm_nameLookUp {
    private static final Logger log = Logger.getLogger(SecondPlaythrouModPlugin.class);

    public spm_nameLookUp(){}
    public void ListAllEntities(){
        log.info("------------- ListAllEntities Start -------------");
        for(StarSystemAPI system: Global.getSector().getStarSystems()){
            for(SectorEntityToken entityToken: system.getAllEntities()){
                log.info("  Name: " + entityToken.getName() + "  ID: " + entityToken.getId());
                String tags = "";
                for(String tag : entityToken.getTags()) {tags = tags + tag + ", ";}
                log.info("      tags: " + tags);
            }
        }
        log.info("------------- ListAllEntities End -------------");
    }
    public void ListAllEntitiesWithString(String name){
        log.info("------------- ListAllEntitiesWithString Start -------------");
        for(StarSystemAPI system: Global.getSector().getStarSystems()){
            for(SectorEntityToken entityToken: system.getAllEntities()){
                if(!entityToken.getName().contains(name))
                    continue;
                log.info("  Name: " + entityToken.getName() + "  ID: " + entityToken.getId());
                String tags = "";
                for(String tag : entityToken.getTags()) {tags = tags + tag + ", ";}
                log.info("      tags: " + tags);
            }
        }
        log.info("------------- ListAllEntitiesWithString End -------------");
    }
    public void ListAllStations(){
        log.info("------------- ListAllStations Start -------------");
        for(SectorEntityToken entityToken : Global.getSector().getEntitiesWithTag("station")){
            log.info("  Name: " + entityToken.getName() + "  ID: " + entityToken.getId());
            String tags = "";
            for(String tag : entityToken.getTags()) {tags = tags + tag + ", ";}
            log.info("      tags: " + tags);
            Map<String, AbilityPlugin> abilityMap = entityToken.getAbilities();
            if(abilityMap == null)
                log.info("      No abilities");
            for (String key : abilityMap.keySet()) {
                AbilityPlugin value = abilityMap.get(key);
                log.info("      Key: " + key + "  Value: " + value);
            }
        }
        log.info("------------- ListAllStations End -------------");
    }
}
