package mllhild.spm.util.Misc;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BattleAPI;
import com.fs.starfarer.api.campaign.CampaignEventListener;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.listeners.FleetEventListener;
import mllhild.spm.SecondPlaythrouModPlugin;
import org.apache.log4j.Logger;

import java.util.Iterator;

public class spm_playerRenown implements FleetEventListener {
    private static final Logger log = Logger.getLogger(SecondPlaythrouModPlugin.class);
    public float maxFleetPointsBeaten = 0;
    public float maxfactor = 1;
    public float playerFleetPoints = 0;

    public spm_playerRenown() {
    }

    public void reportFleetDespawnedToListener(CampaignFleetAPI fleet, CampaignEventListener.FleetDespawnReason reason, Object param) {
    }

    public void reportBattleOccurred(CampaignFleetAPI fleet, CampaignFleetAPI primaryWinner, BattleAPI battle) {
        if (primaryWinner.getFaction().equals(Global.getSector().getPlayerFaction())) {
            log.info("spm_playerRenown reportBattleOccurred with player victor");
            int playerSideFP = 0;
            for(CampaignFleetAPI fleet1 : battle.getPlayerSide()){
                playerSideFP += fleet1.getFleetPoints();
            }
            log.info("playerSideFP " + playerSideFP);
            int enemySideFP = 0;
            for(CampaignFleetAPI fleet1 : battle.getNonPlayerSide()){
                enemySideFP += fleet1.getFleetPoints();
            }
            log.info("enemySideFP " + enemySideFP);
            if(maxFleetPointsBeaten < enemySideFP)
                if(Global.getSector().getPlayerFleet().getFleetPoints() == playerSideFP)
                    maxFleetPointsBeaten = enemySideFP;

            if((enemySideFP < 50))
                return;

            float strengthFactor = enemySideFP/playerSideFP;
            log.info("strengthFactor " + strengthFactor);
            log.info("maxfactor old " + maxfactor);
            if(strengthFactor > maxfactor)
                maxfactor = (maxfactor + strengthFactor) / 2;
            log.info("maxfactor new " + maxfactor);
            int currentPlayerFP = Global.getSector().getPlayerFleet().getFleetPoints();
            playerFleetPoints = currentPlayerFP * maxfactor;
            log.info("         playerFleetPoints " + currentPlayerFP);
            log.info("apparent playerFleetPoints " + playerFleetPoints);
        }

    }
}