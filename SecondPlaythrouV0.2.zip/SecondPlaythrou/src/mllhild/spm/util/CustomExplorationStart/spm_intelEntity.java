package mllhild.spm.util.CustomExplorationStart;

import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.ui.SectorMapAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import org.lwjgl.util.vector.Vector2f;

import java.util.Set;

public class spm_intelEntity extends BaseIntelPlugin {
    spm_intelEntity(SectorEntityToken sectorEntityToken){
        this.entity = sectorEntityToken;
    }
    SectorEntityToken entity;
    @Override
    public String getIcon() {
        if(entity.getCustomEntitySpec().getIconName() != null)
            return entity.getCustomEntitySpec().getIconName();
        else
            return "graphics/icons/generic_probe_icon.png";
    }
    @Override
    public SectorEntityToken getMapLocation(SectorMapAPI map) {
        return entity;
    }
    @Override
    protected String getName() {
        return entity.getName();
    }

    public Set<String> getIntelTags(SectorMapAPI map) {
        Set<String> tags = super.getIntelTags(map);
        tags.add("Salvage");
        return tags;
    }
    @Override
    public void createSmallDescription(TooltipMakerAPI info, float width, float height) {
        info.addPara(entity.getName(), Misc.getTextColor(), 0f);

        double radius = Math.sqrt(
                        (entity.getLocation().x - entity.getOrbitFocus().getLocation().x)*(entity.getLocation().x - entity.getOrbitFocus().getLocation().x)
                        +
                        (entity.getLocation().y - entity.getOrbitFocus().getLocation().y)*(entity.getLocation().y - entity.getOrbitFocus().getLocation().y)
                );
        info.addPara("Is orbiting "+entity.getOrbitFocus().getName() + " at a distance of " + (int)radius + "su", Misc.getTextColor(), 0f);
    }

    @Override
    public void addDeleteButton(TooltipMakerAPI info, float width) {
        addDeleteButton(info, width, "Delete log entry");
    }

    @Override
    public boolean shouldRemoveIntel() {
//        if(entity.hasTag(Tags.SALVAGEABLE))
//            return true;
//        else
//            return false;
            return false;
    }
}
