package mllhild.spm.util.CustomExplorationStart;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.comm.IntelInfoPlugin;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.listeners.GateTransitListener;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.impl.campaign.DerelictShipEntityPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.rulecmd.AddRemoveCommodity;
import com.fs.starfarer.api.plugins.SurveyPlugin;
import com.fs.starfarer.api.ui.SectorMapAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.impl.campaign.GateEntityPlugin;
import com.fs.starfarer.api.impl.campaign.abilities.BaseDurationAbility;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.intel.misc.GateIntel;
import com.fs.starfarer.api.impl.campaign.rulecmd.missions.GateCMD;
import lunalib.lunaSettings.LunaSettings;
import mllhild.spm.SecondPlaythrouModPlugin;
import org.apache.log4j.Logger;

public class spm_CustomExplorationStart {
    private static final Logger log = Logger.getLogger(SecondPlaythrouModPlugin.class);

    public void LunaStart() {
        log.info("Second Playthrouu");

        Double preliminarysurveyChance = LunaSettings.getDouble("SecondPlaythrou", "preliminarysurveyStart");
        GetPreliminarySurveys(preliminarysurveyChance);

        Double surveyChance = LunaSettings.getDouble("SecondPlaythrou", "surveyStart");
        Boolean surveyStartGetData = LunaSettings.getBoolean("SecondPlaythrou", "surveyStartGetData");
        GetSurveys(surveyChance, surveyStartGetData);

        String gateStates = LunaSettings.getString("SecondPlaythrou","gate");


        for(StarSystemAPI systemAPI : Global.getSector().getStarSystems()){
            if(LunaSettings.getBoolean("SecondPlaythrou", "cryosleepersKnown"))
                Cryosleepers();
            if(LunaSettings.getBoolean("SecondPlaythrou", "hypershuntKnown"))
                Hypershunts();
            if(LunaSettings.getBoolean("SecondPlaythrou", "stationsKnown"))
                Stations(systemAPI);
            if(LunaSettings.getBoolean("SecondPlaythrou", "mothershipKnown"))
                Motherships(systemAPI);
            if(LunaSettings.getBoolean("SecondPlaythrou", "surveyShipKnown"))
                SurveyShips(systemAPI);
//            if(LunaSettings.getBoolean("SecondPlaythrou", "surveyProbesKnown"))
//                SurveyProbes(systemAPI);
//            if(LunaSettings.getBoolean("SecondPlaythrou", "salvagableShips"))
//                SalvagableShips(systemAPI);
            if(LunaSettings.getBoolean("SecondPlaythrou", "cratesKnown"))
                SalvagableCaches(systemAPI);
        }



    }

    public void GetPreliminarySurveys(double fraction){
        for(StarSystemAPI system: Global.getSector().getStarSystems()){
            for(PlanetAPI planet: system.getPlanets()){
                MarketAPI market = planet.getMarket();
                if (market == null)
                    continue;
                int marketSize = market.getSize();
                if(marketSize == 1){
                    if(fraction > Math.random()*100){
                        Misc.setPreliminarySurveyed(market,null,false);
                    }
                }
                if(marketSize > 1){
                }
            }
        }
    }
    public void GetSurveys(double fraction, Boolean surveyStartGetData){
        for(StarSystemAPI system: Global.getSector().getStarSystems()){
            for(PlanetAPI planet: system.getPlanets()){
                MarketAPI market = planet.getMarket();
                if (market == null)
                    continue;
                int marketSize = market.getSize();
                if(marketSize == 1){
                    if(fraction > Math.random()*100){
                        Misc.setPreliminarySurveyed(market,null,false);
                        Misc.setFullySurveyed(market, null, false);
                        if(surveyStartGetData){
                            log.info(system.getBaseName() + " - " + planet.getName());
                            SurveyPlugin plugin = (SurveyPlugin) Global.getSettings().getNewPluginInstance("surveyPlugin");
                            plugin.init(Global.getSector().getPlayerFleet(), planet);
                            String dataType = plugin.getSurveyDataType(planet);
                            if (dataType != null) {
                                CargoAPI cargoAPI = Global.getSector().getPlayerFleet().getCargo();
                                if(cargoAPI == null)
                                    log.info("Cant get Player cargo");
                                Global.getSector().getPlayerFleet().getCargo().addCommodity(dataType, 1);
                            }
                        }
                    }
                }
                if(marketSize > 1){
                }
            }
        }
    }
    public void GetGatesScanned(String gateStates){

        if(gateStates.equalsIgnoreCase("none"))
            return;



        //CargoAPI cargo = Global.getSector().getPlayerFleet().getCargo();
        //cargo.addSpecial(new SpecialItemData(Items.JANUS, null), 1);
        Global.getSector().getMemoryWithoutUpdate().set(GateEntityPlugin.GATES_ACTIVE, true);
        Global.getSector().getMemoryWithoutUpdate().set(GateEntityPlugin.PLAYER_CAN_USE_GATES, true);
        //GateIntel.
        //GateEntityPlugin.GateData
        //GateCMD



        if(LunaSettings.getBoolean("SecondPlaythrou", "canScanGates"))
            Global.getSector().getMemoryWithoutUpdate().set(GateEntityPlugin.CAN_SCAN_GATES, true);

        for(SectorEntityToken gate : Global.getSector().getCustomEntitiesWithTag(Tags.GATE)){

            if(GateEntityPlugin.isScanned(gate))
                continue;

            Boolean gateIsCore = false;
            float x = gate.getStarSystem().getHyperspaceAnchor().getLocation().getX();
            float y = gate.getStarSystem().getHyperspaceAnchor().getLocation().getY();
            if(15000 > Math.sqrt(x*x+y*y))
                gateIsCore = true;

            if(gateStates.equalsIgnoreCase("Core known and scanned")){
                if(gateIsCore){
                    GateEntityPlugin.isScanned(gate);
                    gate.getMemoryWithoutUpdate().set(GateEntityPlugin.GATE_SCANNED,true);
                    GateEntityPlugin.addGateScanned();
                    GateEntityPlugin.getGateData().scanned.add(gate);
                    GateEntityPlugin.isActive(gate);
                    GateCMD.notifyScanned(gate);
                    gate.setDiscoverable(false);
                    Global.getSector().getIntelManager().addIntel(new GateIntel(gate));
                }
            }
            if(gateStates.equalsIgnoreCase("All known and scanned")){
                GateEntityPlugin.isScanned(gate);
                gate.getMemoryWithoutUpdate().set(GateEntityPlugin.GATE_SCANNED,true);
                GateEntityPlugin.isActive(gate);
                GateCMD.notifyScanned(gate);
                gate.setDiscoverable(false);
                Global.getSector().getIntelManager().addIntel(new GateIntel(gate));

            }
            if(gateStates.equalsIgnoreCase("All known")){
                Global.getSector().getIntelManager().addIntel(new GateIntel(gate));
                gate.setDiscoverable(false);
            }
        }
    }

    public void Cryosleepers(){
        log.info("Cryosleepers list");
        for (SectorEntityToken entityToken : Global.getSector().getCustomEntitiesWithTag(Tags.CRYOSLEEPER)) {
            log.info(entityToken.getName());
            if(!entityToken.isDiscoverable())
                continue;
            entityToken.setDiscoverable(false);
            Global.getSector().getIntelManager().addIntel(new spm_intelEntity(entityToken));
        }
    }
    public void Hypershunts(){
        log.info("Hypershunts list");
        for(SectorEntityToken entityToken : Global.getSector().getCustomEntitiesWithTag(Tags.CORONAL_TAP)){
            log.info(entityToken.getName());
            if(!entityToken.isDiscoverable())
                continue;
            entityToken.setDiscoverable(false);
            Global.getSector().getIntelManager().addIntel(new spm_intelEntity(entityToken));
        }
    }
    public void Stations(StarSystemAPI system){
        log.info("Stations list");
        for (SectorEntityToken entityToken : system.getCustomEntitiesWithTag(Tags.SALVAGEABLE)) {
            log.info(entityToken.getName());
            if(!entityToken.isDiscoverable())
                continue;
            if(!entityToken.getName().contains("Station") && !entityToken.getName().contains("Habitat"))
                continue;
            entityToken.setDiscoverable(false);
            Global.getSector().getIntelManager().addIntel(new spm_intelEntity(entityToken));
        }
    }
    public void Motherships(StarSystemAPI system){
        log.info("Motherships list");
        for (SectorEntityToken entityToken : system.getCustomEntitiesWithTag(Tags.SALVAGEABLE)) {
            log.info(entityToken.getName());
            if(!entityToken.isDiscoverable())
                continue;
            if(!entityToken.getName().contains("Mother"))
                continue;
            entityToken.setDiscoverable(false);
            Global.getSector().getIntelManager().addIntel(new spm_intelEntity(entityToken));
        }
    }
    public void SurveyShips(StarSystemAPI system){
        log.info("SurveyShips list");
        for (SectorEntityToken entityToken : system.getCustomEntitiesWithTag(Tags.SALVAGEABLE)) {
            log.info(entityToken.getName());
            if(!entityToken.isDiscoverable())
                continue;
            if(!entityToken.getName().contains("Survey"))
                continue;
            entityToken.setDiscoverable(false);
            Global.getSector().getIntelManager().addIntel(new spm_intelEntity(entityToken));
        }
    }
    public void SurveyProbes(StarSystemAPI system){
        log.info("SurveyProbes list");
        for (SectorEntityToken entityToken : system.getCustomEntitiesWithTag(Tags.SALVAGEABLE)) {
            log.info(entityToken.getName());
            if(!entityToken.isDiscoverable())
                continue;
            if(!entityToken.getName().contains("Probe"))
                continue;
            entityToken.setDiscoverable(false);
            Global.getSector().getIntelManager().addIntel(new spm_intelEntity(entityToken));
        }
    }
    public void SalvagableShips(StarSystemAPI system){
        log.info("SalvagableShips list");
        for (SectorEntityToken entityToken : system.getCustomEntitiesWithTag(Tags.SALVAGEABLE)) {
            log.info(entityToken.getName());
            if(!entityToken.isDiscoverable())
                continue;
            if(!entityToken.getName().contains("Derelict Ship"))
                continue;
            entityToken.setDiscoverable(false);
            Global.getSector().getIntelManager().addIntel(new spm_intelEntity(entityToken));
        }

    }
    public void SalvagableCaches(StarSystemAPI system){
        log.info("SalvagableCaches list");
        for (SectorEntityToken entityToken : system.getCustomEntitiesWithTag(Tags.SALVAGEABLE)) {
            log.info(entityToken.getName());
            if(!entityToken.isDiscoverable())
                continue;
            if(!entityToken.getName().contains("Cache"))
                continue;
            entityToken.setDiscoverable(false);
            Global.getSector().getIntelManager().addIntel(new spm_intelEntity(entityToken));
        }
    }


}
