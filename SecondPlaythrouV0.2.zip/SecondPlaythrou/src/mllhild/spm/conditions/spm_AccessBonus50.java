package mllhild.spm.conditions;

import com.fs.starfarer.api.impl.campaign.econ.BaseMarketConditionPlugin;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class spm_AccessBonus50 extends BaseMarketConditionPlugin {
    public static float ACCESSIBILITY_MOD = 0.5F;

    public spm_AccessBonus50() {
    }

    public void apply(String id) {
        this.market.getAccessibilityMod().modifyFlat(id, ACCESSIBILITY_MOD, "2nd PT Access Bonus");
    }

    public void unapply(String id) {
        this.market.getAccessibilityMod().unmodify(id);
    }

    protected void createTooltipAfterDescription(TooltipMakerAPI tooltip, boolean expanded) {
        tooltip.addSpacer(8.0F);
        tooltip.addPara("Adds accessibility to offset distance from core due to reshuffle.", 10.0F);
        tooltip.addSpacer(8.0F);
        tooltip.addPara("%s accessibility Bonus", 0.0F, Misc.getHighlightColor(), new String[]{" " + Math.round(ACCESSIBILITY_MOD * 100.0F) + "%"});
        tooltip.addSpacer(8.0F);
    }
}