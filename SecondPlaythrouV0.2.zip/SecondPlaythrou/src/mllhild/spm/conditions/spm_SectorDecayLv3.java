package mllhild.spm.conditions;

import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MutableCommodityQuantity;
import com.fs.starfarer.api.impl.campaign.econ.BaseMarketConditionPlugin;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import java.util.Iterator;
import java.util.List;

public class spm_SectorDecayLv3 extends BaseMarketConditionPlugin {
    public static float INCOME_MULT = -0.3F;
    public static float ACCESSIBILITY_MOD = -0.3F;
    public static int STABILITY_BONUS = -3;
    public static int SUPPLY_BONUS = -3;

    public spm_SectorDecayLv3() {
    }

    public void apply(String id) {
        List<Industry> inds = this.market.getIndustries();
        Iterator i1 = inds.iterator();

        while(i1.hasNext()) {
            Industry industry = (Industry)i1.next();
            List<MutableCommodityQuantity> mcqs = industry.getAllSupply();
            Iterator i2 = mcqs.iterator();

            while(i2.hasNext()) {
                MutableCommodityQuantity mcq = (MutableCommodityQuantity)i2.next();
                if (mcq.getCommodityId().equalsIgnoreCase("ships")) {
                    industry.getSupply("ships").getQuantity().modifyFlat(id, (float)SUPPLY_BONUS, "Sector Decay Lv1");
                }

                if (mcq.getCommodityId().equalsIgnoreCase("fuel")) {
                    industry.getSupply("fuel").getQuantity().modifyFlat(id, (float)SUPPLY_BONUS, "Sector Decay Lv1");
                }

                if (mcq.getCommodityId().equalsIgnoreCase("heavy_machinery")) {
                    industry.getSupply("heavy_machinery").getQuantity().modifyFlat(id, (float)SUPPLY_BONUS, "Sector Decay Lv1");
                }

                if (mcq.getCommodityId().equalsIgnoreCase("rare_metals")) {
                    industry.getSupply("rare_metals").getQuantity().modifyFlat(id, (float)SUPPLY_BONUS, "Sector Decay Lv1");
                }
            }
        }

        this.market.getIncomeMult().modifyMult(id, 1.0F + INCOME_MULT, "Sector Decay Lv1");
        this.market.getAccessibilityMod().modifyFlat(id, ACCESSIBILITY_MOD, "Sector Decay Lv1");
        this.market.getStability().modifyFlat(id, (float)STABILITY_BONUS, "Sector Decay Lv1");
    }

    public void unapply(String id) {
        this.market.getStability().unmodify(id);
        this.market.getIncomeMult().unmodify(id);
        this.market.getAccessibilityMod().unmodify(id);
        List<Industry> inds = this.market.getIndustries();
        Iterator i3 = inds.iterator();

        while(i3.hasNext()) {
            Industry industry = (Industry)i3.next();
            industry.getSupplyBonusFromOther().unmodify(id);
        }

    }

    protected void createTooltipAfterDescription(TooltipMakerAPI tooltip, boolean expanded) {
        tooltip.addSpacer(8.0F);
        tooltip.addPara("%s income", 0.0F, Misc.getHighlightColor(), new String[]{" " + Math.round(INCOME_MULT * 100.0F) + "%"});
        tooltip.addSpacer(8.0F);
        tooltip.addPara("%s accessibility", 0.0F, Misc.getHighlightColor(), new String[]{" " + Math.round(ACCESSIBILITY_MOD * 100.0F) + "%"});
        tooltip.addSpacer(8.0F);
        tooltip.addPara("%s stability", 0.0F, Misc.getHighlightColor(), new String[]{" " + STABILITY_BONUS});
        tooltip.addSpacer(8.0F);
        tooltip.addPara("%s production to ship hulls, heavy machinery, rare metals, fuel", 0.0F, Misc.getHighlightColor(), new String[]{" " + SUPPLY_BONUS});
    }
}
